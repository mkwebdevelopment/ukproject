<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Datadirectory
 * @author     raj <raj.k230@gmail.com>
 * @copyright  2017 raj
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.modeladmin');

/**
 * Datadirectory model.
 *
 * @since  1.6
 */
class DatadirectoryModelEditsupplier extends JModelAdmin
{
	public function getForm ($data = array(), $loadData = true)
	{
	
	}
}
