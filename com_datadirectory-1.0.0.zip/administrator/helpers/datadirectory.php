<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Datadirectory
 * @author     raj <raj.k230@gmail.com>
 * @copyright  2017 raj
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Datadirectory helper.
 *
 * @since  1.6
 */
class DatadirectoryHelpersDatadirectory
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  string
	 *
	 * @return void
	 */
	public static function addSubmenu($vName = '')
	{
				JHtmlSidebar::addEntry(
			JText::_('COM_DATADIRECTORY_TITLE_EDITPRODUCTS'),
			'index.php?option=com_datadirectory&view=editproducts',
			$vName == 'editproducts'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_DATADIRECTORY_TITLE_EDITSUPPLIERS'),
			'index.php?option=com_datadirectory&view=editsuppliers',
			$vName == 'editsuppliers'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_DATADIRECTORY_TITLE_LISTSUPPLIERPRODUCTSS'),
			'index.php?option=com_datadirectory&view=listsupplierproductss',
			$vName == 'listsupplierproductss'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_DATADIRECTORY_TITLE_LISTSUPPLIERSS'),
			'index.php?option=com_datadirectory&view=listsupplierss',
			$vName == 'listsupplierss'
		);
	}

	/**
	 * Gets the files attached to an item
	 *
	 * @param   int     $pk     The item's id
	 *
	 * @param   string  $table  The table's name
	 *
	 * @param   string  $field  The field's name
	 *
	 * @return  array  The files
	 */
	public static function getFiles($pk, $table, $field)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($field)
			->from($table)
			->where('id = ' . (int) $pk);

		$db->setQuery($query);

		return explode(',', $db->loadResult());
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return    JObject
	 *
	 * @since    1.6
	 */
	public static function getActions()
	{
		$user   = JFactory::getUser();
		$result = new JObject;

		$assetName = 'com_datadirectory';

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action)
		{
			$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}
}


class DatadirectoryHelper extends DatadirectoryHelpersDatadirectory
{

}
